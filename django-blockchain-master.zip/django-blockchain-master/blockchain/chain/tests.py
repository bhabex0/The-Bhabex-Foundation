from django.test import TestCase

# Create your tests here.
#TODO: write unittests for block hashing, lookup etc