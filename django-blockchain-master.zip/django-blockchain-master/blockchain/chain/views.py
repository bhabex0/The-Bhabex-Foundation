from django.shortcuts import render

# check api.v0.views for JSON api
